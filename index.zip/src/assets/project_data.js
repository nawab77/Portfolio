import project1_img from "../assets/project_1.png";
import project2_img from "../assets/project_2.png";
import project3_img from "../assets/project_3.png";

const mywork_data = [
  {
    w_no: 1,
    w_name: "Web design",
    w_img: project1_img,
  },
  {
    w_no: 2,
    w_name: "Web design",
    w_img: project2_img,
  },
  {
    w_no: 3,
    w_name: "Web design",
    w_img: project3_img,
  },
];

export default mywork_data;
