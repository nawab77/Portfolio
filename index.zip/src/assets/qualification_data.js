const Qualification_Data = [
  {
    s_name: "Bachlor in Science",
    s_desc: "NIIS Institute of Information Science & Management, Bhubaneswar. ",
    s_no: "70%",
  },
  {
    s_name: "12th (Science)",
    s_desc: "New Star Science College, Khordha",
    s_no: "53%",
  },
  {
    s_name: "Matriculation",
    s_desc: "Zaitun Nisa High School, Keranga.",
    s_no: "67%",
  },
];

export default Qualification_Data;
